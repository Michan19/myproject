package com.ecommerce.backend.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ecommerce.backend.entities.Product;
import com.ecommerce.backend.exceptions.ResourceNotFoundException;
import com.ecommerce.backend.repositories.ProductRepository;
import com.ecommerce.backend.services.impl.ProductServiceImpl;

public class ProductServiceImplTest {

	@Mock
	private ProductRepository productRepository;

	@InjectMocks
	private ProductServiceImpl productService;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testGetAllProducts() {
		when(productRepository.findAll()).thenReturn(Arrays.asList(new Product(), new Product()));

		assertEquals(2, productService.getAllProducts().size());
	}

	@Test
	public void testGetProductById() {
		Product product = new Product();
		product.setProductID(1L);
		when(productRepository.findById(1L)).thenReturn(Optional.of(product));

		Optional<Product> result = productService.getProductById(1L);
		assertTrue(result.isPresent());
		assertEquals(1L, result.get().getProductID());
	}

	@Test
	public void testGetProductById_NotFound() {
		when(productRepository.findById(1L)).thenReturn(Optional.empty());

		assertThrows(ResourceNotFoundException.class, () -> productService.getProductById(1L)
				.orElseThrow(() -> new ResourceNotFoundException("Product not found")));
	}

	@Test
	public void testCreateProduct() {
		Product product = new Product();
		product.setName("Test Product");

		when(productRepository.save(any(Product.class))).thenReturn(product);

		Product result = productService.createProduct(product);
		assertEquals("Test Product", result.getName());
	}

	@Test
	public void testUpdateProduct() {
		Product product = new Product();
		product.setProductID(1L);
		product.setName("Original Product");

		Product updatedProduct = new Product();
		updatedProduct.setName("Updated Product");

		when(productRepository.findById(1L)).thenReturn(Optional.of(product));
		when(productRepository.save(any(Product.class))).thenReturn(updatedProduct);

		Product result = productService.updateProduct(1L, updatedProduct);
		assertEquals("Updated Product", result.getName());
	}

	@Test
	public void testDeleteProduct() {
		Product product = new Product();
		product.setProductID(1L);

		when(productRepository.findById(1L)).thenReturn(Optional.of(product));
		doNothing().when(productRepository).delete(product);

		String result = productService.deleteProduct(1L);

		assertEquals("Product deleted successfully", result);
		verify(productRepository).delete(product);
	}
}