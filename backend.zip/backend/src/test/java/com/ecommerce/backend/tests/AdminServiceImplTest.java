package com.ecommerce.backend.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.ecommerce.backend.dto.AdminDTO;
import com.ecommerce.backend.dto.ProductDTO;
import com.ecommerce.backend.dto.UserDTO;
import com.ecommerce.backend.entities.Admin;
import com.ecommerce.backend.entities.Order;
import com.ecommerce.backend.entities.Product;
import com.ecommerce.backend.entities.User;
import com.ecommerce.backend.exceptions.ResourceNotFoundException;
import com.ecommerce.backend.repositories.AdminRepository;
import com.ecommerce.backend.repositories.OrderRepository;
import com.ecommerce.backend.repositories.ProductRepository;
import com.ecommerce.backend.repositories.UserRepository;
import com.ecommerce.backend.services.impl.AdminServiceImpl;

public class AdminServiceImplTest {

    @InjectMocks
    private AdminServiceImpl adminService;

    @Mock
    private AdminRepository adminRepository;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateAdmin() {
        AdminDTO adminDTO = new AdminDTO();
        adminDTO.setName("John Doe");
        adminDTO.setRole("Admin");
        adminDTO.setPermissions("READ,WRITE");
        adminDTO.setEmail("john.doe@example.com");
        adminDTO.setPassword("password123");

        Admin admin = new Admin();
        admin.setAdminID(1L);
        admin.setName(adminDTO.getName());
        admin.setRole(adminDTO.getRole());
        admin.setPermissions(adminDTO.getPermissions());
        admin.setEmail(adminDTO.getEmail());
        admin.setPassword("encodedPassword123");

        when(adminRepository.save(any(Admin.class))).thenReturn(admin);
        when(passwordEncoder.encode(adminDTO.getPassword())).thenReturn("encodedPassword123");

        AdminDTO result = adminService.createAdmin(adminDTO);

        assertEquals(admin.getAdminID(), result.getAdminID());
        assertEquals(admin.getName(), result.getName());
        assertEquals(admin.getRole(), result.getRole());
        assertEquals(admin.getPermissions(), result.getPermissions());
        assertEquals(admin.getEmail(), result.getEmail());
        assertEquals("encodedPassword123", admin.getPassword());
    }

    @Test
    public void testGetAdminById() {
        Admin admin = new Admin();
        admin.setAdminID(1L);
        admin.setName("John Doe");
        admin.setRole("Admin");
        admin.setPermissions("READ,WRITE");
        admin.setEmail("john.doe@example.com");
        admin.setPassword("encodedPassword123");

        when(adminRepository.findById(1L)).thenReturn(Optional.of(admin));

        AdminDTO result = adminService.getAdminById(1L);

        assertEquals(admin.getAdminID(), result.getAdminID());
        assertEquals(admin.getName(), result.getName());
        assertEquals(admin.getRole(), result.getRole());
        assertEquals(admin.getPermissions(), result.getPermissions());
        assertEquals(admin.getEmail(), result.getEmail());
        assertEquals(admin.getPassword(), result.getPassword());
    }

    @Test
    public void testGetAdminById_NotFound() {
        when(adminRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> adminService.getAdminById(1L));
    }

    @Test
    public void testGetAllAdmins() {
        Admin admin1 = new Admin();
        admin1.setAdminID(1L);
        admin1.setName("John Doe");
        admin1.setRole("Admin");
        admin1.setPermissions("READ,WRITE");
        admin1.setEmail("john.doe@example.com");
        admin1.setPassword("encodedPassword123");

        Admin admin2 = new Admin();
        admin2.setAdminID(2L);
        admin2.setName("Jane Doe");
        admin2.setRole("Admin");
        admin2.setPermissions("READ,WRITE");
        admin2.setEmail("jane.doe@example.com");
        admin2.setPassword("encodedPassword123");

        when(adminRepository.findAll()).thenReturn(Arrays.asList(admin1, admin2));

        List<AdminDTO> result = adminService.getAllAdmins();

        assertEquals(2, result.size());
        assertEquals(admin1.getAdminID(), result.get(0).getAdminID());
        assertEquals(admin2.getAdminID(), result.get(1).getAdminID());
    }

    @Test
    public void testUpdateAdmin() {
        Admin admin = new Admin();
        admin.setAdminID(1L);
        admin.setName("John Doe");
        admin.setRole("Admin");
        admin.setPermissions("READ,WRITE");
        admin.setEmail("john.doe@example.com");
        admin.setPassword("encodedPassword123");

        AdminDTO adminDTO = new AdminDTO();
        adminDTO.setName("John Doe Updated");
        adminDTO.setRole("Admin");
        adminDTO.setPermissions("READ,WRITE");
        adminDTO.setEmail("john.doe@example.com");
        adminDTO.setPassword("password123");

        when(adminRepository.findById(1L)).thenReturn(Optional.of(admin));
        when(adminRepository.save(any(Admin.class))).thenReturn(admin);
        when(passwordEncoder.encode(adminDTO.getPassword())).thenReturn("encodedPassword123");

        AdminDTO result = adminService.updateAdmin(1L, adminDTO);

        assertEquals(admin.getAdminID(), result.getAdminID());
        assertEquals(adminDTO.getName(), result.getName());
        assertEquals(adminDTO.getRole(), result.getRole());
        assertEquals(adminDTO.getPermissions(), result.getPermissions());
        assertEquals(adminDTO.getEmail(), result.getEmail());
        assertEquals("encodedPassword123", result.getPassword());
    }

    @Test
    public void testDeleteAdmin() {
        Admin admin = new Admin();
        admin.setAdminID(1L);
        admin.setName("John Doe");
        admin.setRole("Admin");
        admin.setPermissions("READ,WRITE");
        admin.setEmail("john.doe@example.com");
        admin.setPassword("encodedPassword123");

        when(adminRepository.findById(1L)).thenReturn(Optional.of(admin));

        adminService.deleteAdmin(1L);

        verify(adminRepository).delete(admin);
    }

    @Test
    public void testListAllProducts() {
        Product product1 = new Product();
        product1.setProductID(1L);
        product1.setName("Product 1");
        product1.setDescription("Description 1");
        product1.setPrice(new BigDecimal("100.0"));
        product1.setCategory("Category 1");
        product1.setImageURL("URL 1");

        Product product2 = new Product();
        product2.setProductID(2L);
        product2.setName("Product 2");
        product2.setDescription("Description 2");
        product2.setPrice(new BigDecimal("100.0"));
        product2.setCategory("Category 2");
        product2.setImageURL("URL 2");

        when(productRepository.findAll()).thenReturn(Arrays.asList(product1, product2));

        List<ProductDTO> result = adminService.listAllProducts();

        assertEquals(2, result.size());
        assertEquals(product1.getProductID(), result.get(0).getProductID());
        assertEquals(product2.getProductID(), result.get(1).getProductID());
    }

    @Test
    public void testListAllUsers() {
        User user1 = new User();
        user1.setUserID(1L);
        user1.setName("User 1");
        user1.setEmail("user1@example.com");
        user1.setShippingAddress("Address 1");
        user1.setPaymentDetails("Payment 1");

        User user2 = new User();
        user2.setUserID(2L);
        user2.setName("User 2");
        user2.setEmail("user2@example.com");
        user2.setShippingAddress("Address 2");
        user2.setPaymentDetails("Payment 2");

        when(userRepository.findAll()).thenReturn(Arrays.asList(user1, user2));

        List<UserDTO> result = adminService.listAllUsers();

        assertEquals(2, result.size());
        assertEquals(user1.getUserID(), result.get(0).getUserID());
        assertEquals(user2.getUserID(), result.get(1).getUserID());
    }

    @Test
    public void testListAllOrders() {
        Order order1 = new Order();
        order1.setOrderId(1L);
        order1.setTotalPrice(100.0);

        Order order2 = new Order();
        order2.setOrderId(2L);
        order2.setTotalPrice(200.0);

        when(orderRepository.findAll()).thenReturn(Arrays.asList(order1, order2));

        List<Order> result = adminService.listAllOrders();

        assertEquals(2, result.size());
        assertEquals(order1.getOrderId(), result.get(0).getOrderId());
        assertEquals(order2.getOrderId(), result.get(1).getOrderId());
    }
}
