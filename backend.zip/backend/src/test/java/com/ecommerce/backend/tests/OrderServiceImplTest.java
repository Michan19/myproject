
package com.ecommerce.backend.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.apache.coyote.BadRequestException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.ecommerce.backend.dto.OrderConfirmationDTO;
import com.ecommerce.backend.dto.OrderDTO;
import com.ecommerce.backend.entities.CartItem;
import com.ecommerce.backend.entities.Order;
import com.ecommerce.backend.entities.Product;
import com.ecommerce.backend.entities.User;
import com.ecommerce.backend.exceptions.OrderNotFoundException;
import com.ecommerce.backend.repositories.CartRepository;
import com.ecommerce.backend.repositories.OrderRepository;
import com.ecommerce.backend.repositories.UserRepository;
import com.ecommerce.backend.services.UserService;
import com.ecommerce.backend.services.impl.OrderServiceImpl;


public class OrderServiceImplTest {

    @InjectMocks
    private OrderServiceImpl orderService;

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private UserService userService;

    @Mock
    private CartRepository cartRepository;

    @Mock
    private SecurityContext securityContext;

    @Mock
    private Authentication authentication;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        SecurityContextHolder.setContext(securityContext);
    }

    @Test
    public void testShowAllOrders() {
        User user = new User();
        user.setUserID(1L);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.getName()).thenReturn("user@example.com");
        when(userService.findByEmail("user@example.com")).thenReturn(user);
        when(orderRepository.findByUser_UserID(1L)).thenReturn(Arrays.asList(new Order(), new Order()));

        List<Order> orders = orderService.showAllOrders(1L);

        assertEquals(2, orders.size());
    }

    @Test
    public void testAddNewOrder() throws BadRequestException {
        User user = new User();
        user.setUserID(1L);
        user.setName("John Doe");
        user.setShippingAddress("123 Main St");
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.getName()).thenReturn("user@example.com");
        when(userService.findByEmail("user@example.com")).thenReturn(user);
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));

        CartItem cartItem = new CartItem();
        cartItem.setTotalPrice(100.0);
        cartItem.setQuantity(2);
        Product product = new Product();
        product.setName("Product Name");
        cartItem.setProduct(product);
        when(cartRepository.findByCartItemIDAndUserUserID(1L, 1L)).thenReturn(Optional.of(cartItem));

        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setUserId(1L);
        orderDTO.setCartItemId(1L);
        orderDTO.setOrderStatus("Pending");

        Order order = new Order();
        order.setUser(user);
        order.setOrderStatus("Pending");
        order.setTotalPrice(cartItem.getTotalPrice() * cartItem.getQuantity());
        order.setCartItem(cartItem);
        order.setShippingAddress("123 Main St");
        when(orderRepository.save(any(Order.class))).thenReturn(order);

        OrderConfirmationDTO confirmation = orderService.addNewOrder(orderDTO);

        assertEquals(1L, confirmation.getUserId());
        assertEquals("John Doe", confirmation.getUserName());
        assertEquals("Product Name", confirmation.getProductName());
        assertEquals(200.0, confirmation.getTotalPrice());
        assertEquals(2, confirmation.getQuantity());
        assertEquals("123 Main St", confirmation.getShippingAddress());
    }

    @Test
    public void testUpdateAddress() throws OrderNotFoundException {
        User user = new User();
        user.setUserID(1L);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.getName()).thenReturn("user@example.com");
        when(userService.findByEmail("user@example.com")).thenReturn(user);

        Order order = new Order();
        order.setOrderId(1L);
        order.setShippingAddress("Old Address");
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        String result = orderService.updateAddress(1L, 1L, "New Address");

        assertEquals("Shipping Address Updated", result);
        assertEquals("New Address", order.getShippingAddress());
    }

    @Test
    public void testGetOrderStatus() throws OrderNotFoundException {
        User user = new User();
        user.setUserID(1L);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.getName()).thenReturn("user@example.com");
        when(userService.findByEmail("user@example.com")).thenReturn(user);

        Order order = new Order();
        order.setOrderId(1L);
        order.setOrderStatus("Shipped");
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        String status = orderService.getOrderStatus(1L, 1L);

        assertEquals("Shipped", status);
    }

    @Test
    public void testDeleteOrder() throws OrderNotFoundException {
        User user = new User();
        user.setUserID(1L);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.getName()).thenReturn("user@example.com");
        when(userService.findByEmail("user@example.com")).thenReturn(user);

        Order order = new Order();
        order.setOrderId(1L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        String result = orderService.deleteOrder(1L, 1L);

        assertEquals("Order Cancelled", result);
        verify(orderRepository).delete(order);
    }

    @Test
    public void testFindOrderDetails() throws OrderNotFoundException {
        User user = new User();
        user.setUserID(1L);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.getName()).thenReturn("user@example.com");
        when(userService.findByEmail("user@example.com")).thenReturn(user);

        Order order = new Order();
        order.setOrderId(1L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        Order result = orderService.findOrderDetails(1L, 1L);

        assertEquals(order, result);
    }

    @Test
    public void testFindPaymentStatus() throws OrderNotFoundException {
        User user = new User();
        user.setUserID(1L);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.getName()).thenReturn("user@example.com");
        when(userService.findByEmail("user@example.com")).thenReturn(user);

        Order order = new Order();
        order.setOrderId(1L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        String status = orderService.findPaymentStatus(1L, 1L);

        assertEquals("Payment Yet be Done", status);
    }
}
