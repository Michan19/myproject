package com.ecommerce.backend.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ecommerce.backend.dto.CartItemDTO;
import com.ecommerce.backend.entities.CartItem;
import com.ecommerce.backend.entities.Product;
import com.ecommerce.backend.entities.User;
import com.ecommerce.backend.exceptions.ResourceNotFoundException;
import com.ecommerce.backend.repositories.CartRepository;
import com.ecommerce.backend.repositories.ProductRepository;
import com.ecommerce.backend.repositories.UserRepository;
import com.ecommerce.backend.services.impl.CartServiceImpl;

public class CartServiceImplTest {

    @InjectMocks
    private CartServiceImpl cartService;

    @Mock
    private CartRepository cartRepository;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private UserRepository userRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllCartItemsByUserId() {
        User user = new User();
        user.setUserID(1L);

        Product product1 = new Product();
        product1.setProductID(1L);
        product1.setName("Product 1");

        Product product2 = new Product();
        product2.setProductID(2L);
        product2.setName("Product 2");

        CartItem cartItem1 = new CartItem();
        cartItem1.setCartItemID(1L);
        cartItem1.setProduct(product1);
        cartItem1.setUser(user);
        cartItem1.setQuantity(2);
        cartItem1.setTotalPrice(200.0);

        CartItem cartItem2 = new CartItem();
        cartItem2.setCartItemID(2L);
        cartItem2.setProduct(product2);
        cartItem2.setUser(user);
        cartItem2.setQuantity(3);
        cartItem2.setTotalPrice(300.0);

        when(cartRepository.findByUserUserID(1L)).thenReturn(Arrays.asList(cartItem1, cartItem2));

        List<CartItemDTO> cartItems = cartService.getAllCartItemsByUserId(1L);

        assertEquals(2, cartItems.size());
        assertEquals(1L, cartItems.get(0).getCartItemId());
        assertEquals(2L, cartItems.get(1).getCartItemId());
    }

    @Test
    public void testGetCartItemByIdAndUserId() {
        User user = new User();
        user.setUserID(1L);

        Product product = new Product();
        product.setProductID(1L);
        product.setName("Product 1");

        CartItem cartItem = new CartItem();
        cartItem.setCartItemID(1L);
        cartItem.setProduct(product);
        cartItem.setUser(user);
        cartItem.setQuantity(2);
        cartItem.setTotalPrice(200.0);

        when(cartRepository.findByCartItemIDAndUserUserID(1L, 1L)).thenReturn(Optional.of(cartItem));

        CartItemDTO cartItemDTO = cartService.getCartItemByIdAndUserId(1L, 1L);

        assertEquals(1L, cartItemDTO.getCartItemId());
        assertEquals(1L, cartItemDTO.getProductId());
        assertEquals("Product 1", cartItemDTO.getProductName());
        assertEquals(1L, cartItemDTO.getUserId());
        assertEquals(2, cartItemDTO.getQuantity());
        assertEquals(200.0, cartItemDTO.getTotalPrice());
    }

    @Test
    public void testGetCartItemByIdAndUserId_NotFound() {
        when(cartRepository.findByCartItemIDAndUserUserID(1L, 1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> cartService.getCartItemByIdAndUserId(1L, 1L));
    }

    @Test
    public void testDeleteCartItemByIdAndUserId() {
        User user = new User();
        user.setUserID(1L);

        Product product = new Product();
        product.setProductID(1L);
        product.setName("Product 1");

        CartItem cartItem = new CartItem();
        cartItem.setCartItemID(1L);
        cartItem.setProduct(product);
        cartItem.setUser(user);
        cartItem.setQuantity(2);
        cartItem.setTotalPrice(200.0);

        when(cartRepository.findByCartItemIDAndUserUserID(1L, 1L)).thenReturn(Optional.of(cartItem));

        String result = cartService.deleteCartItemByIdAndUserId(1L, 1L);

        assertEquals("Cart Item Deleted Successfully.", result);
        verify(cartRepository).delete(cartItem);
    }

    @Test
    public void testAddCartItem() {
        User user = new User();
        user.setUserID(1L);

        Product product = new Product();
        product.setProductID(1L);
        product.setName("Product 1");
        product.setPrice(new BigDecimal("100.0"));

        CartItemDTO cartItemDTO = new CartItemDTO();
        cartItemDTO.setProductId(1L);
        cartItemDTO.setUserId(1L);
        cartItemDTO.setQuantity(2);

        CartItem cartItem = new CartItem();
        cartItem.setProduct(product);
        cartItem.setUser(user);
        cartItem.setQuantity(2);
        cartItem.setTotalPrice(200.0);

        when(productRepository.findById(1L)).thenReturn(Optional.of(product));
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(cartRepository.save(any(CartItem.class))).thenReturn(cartItem);

        CartItemDTO result = cartService.addCartItem(cartItemDTO);

        assertEquals(1L, result.getProductId());
        assertEquals(1L, result.getUserId());
        assertEquals(2, result.getQuantity());
        assertEquals(200.0, result.getTotalPrice());
    }

    @Test
    public void testUpdateCartItem() {
        User user = new User();
        user.setUserID(1L);

        Product product = new Product();
        product.setProductID(1L);
        product.setName("Product 1");
        product.setPrice(new BigDecimal("100.0"));

        CartItemDTO cartItemDTO = new CartItemDTO();
        cartItemDTO.setProductId(1L);
        cartItemDTO.setUserId(1L);
        cartItemDTO.setQuantity(3);

        CartItem cartItem = new CartItem();
        cartItem.setProduct(product);
        cartItem.setUser(user);
        cartItem.setQuantity(3);
        cartItem.setTotalPrice(300.0);

        when(cartRepository.findByCartItemIDAndUserUserID(1L, 1L)).thenReturn(Optional.of(cartItem));
        when(productRepository.findById(1L)).thenReturn(Optional.of(product));
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(cartRepository.save(any(CartItem.class))).thenReturn(cartItem);

        CartItemDTO result = cartService.updateCartItem(1L, cartItemDTO);

        assertEquals(1L, result.getProductId());
        assertEquals(1L, result.getUserId());
        assertEquals(3, result.getQuantity());
        assertEquals(300.0, result.getTotalPrice());
    }

    @Test
    public void testCalculateTotalPriceForUser() {
        User user = new User();
        user.setUserID(1L);

        Product product1 = new Product();
        product1.setProductID(1L);
        product1.setName("Product 1");

        Product product2 = new Product();
        product2.setProductID(2L);
        product2.setName("Product 2");

        CartItem cartItem1 = new CartItem();
        cartItem1.setCartItemID(1L);
        cartItem1.setProduct(product1);
        cartItem1.setUser(user);
        cartItem1.setQuantity(2);
        cartItem1.setTotalPrice(200.0);

        CartItem cartItem2 = new CartItem();
        cartItem2.setCartItemID(2L);
        cartItem2.setProduct(product2);
        cartItem2.setUser(user);
        cartItem2.setQuantity(3);
        cartItem2.setTotalPrice(300.0);

        when(cartRepository.findByUserUserID(1L)).thenReturn(Arrays.asList(cartItem1, cartItem2));

        Double totalPrice = cartService.calculateTotalPriceForUser(1L);

        assertEquals(500.0, totalPrice);
    }
}