package com.ecommerce.backend.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.ecommerce.backend.entities.User;
import com.ecommerce.backend.repositories.UserRepository;
import com.ecommerce.backend.services.impl.UserServiceImpl;

public class UserServiceImplTest {

    @InjectMocks
    private UserServiceImpl userService;

    @Mock
    private UserRepository userRepository;

    @Mock
    private BCryptPasswordEncoder passwordEncoder;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testSaveUser() {
       User user = new User();
        user.setPassword("password123");

        when(passwordEncoder.encode("password123")).thenReturn("encodedPassword123");
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> {
            User savedUser = invocation.getArgument(0);
            savedUser.setPassword("encodedPassword123");
            return savedUser;
        });

        User savedUser = userService.saveUser(user);

        assertEquals("encodedPassword123", savedUser.getPassword());
        verify(userRepository).save(user);
    }

    @Test
    public void testGetUserById() {
        User user = new User();
        user.setUserID(1L);
        user.setName("John Doe");

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));

        User foundUser = userService.getUserById(1L);

        assertEquals(1L, foundUser.getUserID());
        assertEquals("John Doe", foundUser.getName());
    }

    @Test
    public void testGetUserById_NotFound() {
        when(userRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> userService.getUserById(1L));
    }

    @Test
    public void testUpdateUser() {
        User existingUser = new User();
        existingUser.setUserID(1L);
        existingUser.setPassword("oldPassword");

        User updatedUserDetails = new User();
        updatedUserDetails.setName("John Doe Updated");
        updatedUserDetails.setEmail("john.doe@example.com");
        updatedUserDetails.setPassword("newPassword");
        updatedUserDetails.setShippingAddress("123 Main St");
        updatedUserDetails.setPaymentDetails("Credit Card");
        updatedUserDetails.setRole("User");

        when(userRepository.findById(1L)).thenReturn(Optional.of(existingUser));
        when(passwordEncoder.encode("newPassword")).thenReturn("encodedNewPassword");
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> {
            User savedUser = invocation.getArgument(0);
            savedUser.setPassword("encodedNewPassword");
            return savedUser;
        });

        User updatedUser = userService.updateUser(1L, updatedUserDetails);

        assertEquals("John Doe Updated", updatedUser.getName());
        assertEquals("john.doe@example.com", updatedUser.getEmail());
        assertEquals("encodedNewPassword", updatedUser.getPassword());
        assertEquals("123 Main St", updatedUser.getShippingAddress());
        assertEquals("Credit Card", updatedUser.getPaymentDetails());
        assertEquals("User", updatedUser.getRole());
    }

    @Test
    public void testDeleteUser() {
        userService.deleteUser(1L);

        verify(userRepository).deleteById(1L);
    }

    @Test
    public void testListAllUsers() {
        User user1 = new User();
        user1.setUserID(1L);
        user1.setName("John Doe");

        User user2 = new User();
        user2.setUserID(2L);
        user2.setName("Jane Doe");

        when(userRepository.findAll()).thenReturn(Arrays.asList(user1, user2));

        List<User> users = userService.listAllUsers();

        assertEquals(2, users.size());
        assertEquals(1L, users.get(0).getUserID());
        assertEquals(2L, users.get(1).getUserID());
    }

    @Test
    public void testFindByEmail() {
        User user = new User();
        user.setEmail("john.doe@example.com");

        when(userRepository.findByEmail("john.doe@example.com")).thenReturn(Optional.of(user));

        User foundUser = userService.findByEmail("john.doe@example.com");

        assertEquals("john.doe@example.com", foundUser.getEmail());
    }

    @Test
    public void testFindByEmail_NotFound() {
        when(userRepository.findByEmail("john.doe@example.com")).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> userService.findByEmail("john.doe@example.com"));
    }
}