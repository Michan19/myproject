package com.ecommerce.backend.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.ecommerce.backend.entities.User;
import com.ecommerce.backend.repositories.UserRepository;
import com.ecommerce.backend.services.UserService;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Override
    public User saveUser(User user) {
        // Encode the password before saving
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepository.save(user);
    }

    @Override
    public User getUserById(Long userID) {
        return userRepository.findById(userID).orElseThrow(() -> new RuntimeException("User not found"));
    }

    @Override
    public User updateUser(Long userID, User userDetails) {
        User user = getUserById(userID);
        user.setName(userDetails.getName());
        user.setEmail(userDetails.getEmail());

        // Encode the password if it has been updated
        if (userDetails.getPassword() != null && !userDetails.getPassword().isEmpty()) {
            user.setPassword(passwordEncoder.encode(userDetails.getPassword()));
        }

        user.setShippingAddress(userDetails.getShippingAddress());
        user.setPaymentDetails(userDetails.getPaymentDetails());
        user.setRole(userDetails.getRole());
        return userRepository.save(user);
    }

    @Override
    public String deleteUser(Long userID) {
        userRepository.deleteById(userID);
		return "User Deleted Successfully.";
    }

    @Override
    public List<User> listAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User findByEmail(String email) {
        return userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));
    }
}