package com.ecommerce.backend.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class PaymentDTO {
    @NotNull(message="order id cannot be empty")
	private Long orderId;
	@NotBlank(message = "payment type cannot be blank")
	private String paymentType;
	@NotBlank(message = "payment status cannot be blank")
	private String paymentStatus;
}
