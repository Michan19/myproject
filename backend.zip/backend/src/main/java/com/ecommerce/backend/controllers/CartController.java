package com.ecommerce.backend.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import com.ecommerce.backend.dto.CartItemDTO;
import com.ecommerce.backend.entities.User;
import com.ecommerce.backend.services.CartService;
import com.ecommerce.backend.services.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @Autowired
   UserService userService;

    @GetMapping("/{userId}")
    public List<CartItemDTO> getAllCartItems(@PathVariable Long userId) {
        User authenticatedUser = getAuthenticatedUser();
        if (!authenticatedUser.getUserID().equals(userId)) {
            throw new RuntimeException("You are not authorized to view this user's cart.");
        }
        return cartService.getAllCartItemsByUserId(userId);
    }

    @GetMapping("/{userId}/{cartItemID}")
    public ResponseEntity<CartItemDTO> getCartItemById(@PathVariable Long userId, @PathVariable Long cartItemID) {
        User authenticatedUser = getAuthenticatedUser();
        if (!authenticatedUser.getUserID().equals(userId)) {
            throw new RuntimeException("You are not authorized to view this user's cart item.");
        }
        CartItemDTO cartItemDTO = cartService.getCartItemByIdAndUserId(cartItemID, userId);
        return ResponseEntity.ok(cartItemDTO);
    }

    @PostMapping("/{userId}")
    public ResponseEntity<CartItemDTO> addCartItem(@PathVariable Long userId, @Valid @RequestBody CartItemDTO cartItemDTO) {
        User authenticatedUser = getAuthenticatedUser();
        if (!authenticatedUser.getUserID().equals(userId)) {
            throw new RuntimeException("You are not authorized to add items to this user's cart.");
        }
        cartItemDTO.setUserId(userId);
        CartItemDTO newCartItem = cartService.addCartItem(cartItemDTO);
        return ResponseEntity.ok(newCartItem);
    }


    @PutMapping("/{userId}/{cartItemID}")
    public ResponseEntity<CartItemDTO> updateCartItem(@PathVariable Long userId, @PathVariable Long cartItemID, @RequestBody CartItemDTO cartItemDTO) {
        User authenticatedUser = getAuthenticatedUser();
        if (!authenticatedUser.getUserID().equals(userId)) {
            throw new RuntimeException("You are not authorized to update items in this user's cart.");
        }
        cartItemDTO.setUserId(userId);
        CartItemDTO updatedCartItem = cartService.updateCartItem(cartItemID, cartItemDTO);
        return ResponseEntity.ok(updatedCartItem);
    }

    @DeleteMapping("/{userId}/{cartItemID}")
    public ResponseEntity<String> deleteCartItem(@PathVariable Long userId, @PathVariable Long cartItemID) {
        User authenticatedUser = getAuthenticatedUser();
        if (!authenticatedUser.getUserID().equals(userId)) {
            throw new RuntimeException("You are not authorized to delete items from this user's cart.");
        }
        String deleteMsg = cartService.deleteCartItemByIdAndUserId(cartItemID, userId);
        return ResponseEntity.ok(deleteMsg);
    }

    @GetMapping("/{userId}/totalPrice")
    public ResponseEntity<Double> getTotalPriceForUser(@PathVariable Long userId) {
        User authenticatedUser = getAuthenticatedUser();
        if (!authenticatedUser.getUserID().equals(userId)) {
            throw new RuntimeException("You are not authorized to view this user's total price.");
        }
        Double totalPrice = cartService.calculateTotalPriceForUser(userId);
        return ResponseEntity.ok(totalPrice);
    }

    private User getAuthenticatedUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null) {
            throw new RuntimeException("User is not authenticated");
        }
        String username = authentication.getName();
        return userService.findByEmail(username);
    }
}
