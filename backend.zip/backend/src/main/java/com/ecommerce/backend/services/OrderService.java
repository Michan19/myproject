package com.ecommerce.backend.services;

import java.util.List;

import org.apache.coyote.BadRequestException;
import org.springframework.stereotype.Service;

import com.ecommerce.backend.dto.OrderConfirmationDTO;
import com.ecommerce.backend.dto.OrderDTO;
import com.ecommerce.backend.entities.Order;
import com.ecommerce.backend.exceptions.OrderNotFoundException;

@Service
public interface OrderService {
	List<Order> showAllOrders(Long userId);
	OrderConfirmationDTO addNewOrder(OrderDTO orderDto)throws BadRequestException;
	String updateAddress(Long userId,Long orderId,String address) throws OrderNotFoundException;
	String getOrderStatus(Long userId,Long orderId) throws OrderNotFoundException;
	String deleteOrder(Long userId,Long orderId) throws OrderNotFoundException;
	Order findOrderDetails(Long userId,Long orderId) throws OrderNotFoundException;
	String findPaymentStatus(Long userId,Long orderId) throws OrderNotFoundException;
}
