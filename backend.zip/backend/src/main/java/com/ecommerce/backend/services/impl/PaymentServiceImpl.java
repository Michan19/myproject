package com.ecommerce.backend.services.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.ecommerce.backend.dto.PaymentDTO;
import com.ecommerce.backend.entities.Order;
import com.ecommerce.backend.entities.Payment;
import com.ecommerce.backend.entities.User;
import com.ecommerce.backend.exceptions.OrderNotFoundException;
import com.ecommerce.backend.repositories.OrderRepository;
import com.ecommerce.backend.repositories.PaymentRepository;
import com.ecommerce.backend.services.PaymentService;
import com.ecommerce.backend.services.UserService;
@Service
public class PaymentServiceImpl implements PaymentService {
    @Autowired
    private PaymentRepository paymentRepository;
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private UserService userService;
    private User getAuthenticatedUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null) {
            throw new RuntimeException("User is not authenticated");
        }
        String username = authentication.getName();
        return userService.findByEmail(username);
    }
	@Override
	public String doPayment(Long userId,PaymentDTO paymentDto) throws OrderNotFoundException {
		//return paymentRepository.save(payment);
		User authenticatedUser = getAuthenticatedUser();
		if (!authenticatedUser.getUserID().equals(userId)) {
			throw new RuntimeException("You are not authorized to pay for someone else.");
		}
		Order order=orderRepository.findById(paymentDto.getOrderId()).orElseThrow(()->new OrderNotFoundException("Order Does not exist"));
		Payment pay=convertToEntity(paymentDto);
		paymentRepository.save(pay);
	    order.setPayment(pay);
	    orderRepository.save(order);
		return "Paid Successfully!";
	}
	
	
	private Payment convertToEntity(PaymentDTO paymentDto) {
		Payment pay=new Payment();
		pay.setPaymentStatus(paymentDto.getPaymentStatus());
		pay.setPaymentType(paymentDto.getPaymentType());
		return pay;
	}
//	@Override
//	public Order paymentForOrder(Long orderId,Payment payment) throws OrderNotFoundException,PaymentAlreadyDoneException{
//		Order order=orderRepository.findById(orderId).orElseThrow(()->new OrderNotFoundException("No Such order with ID "+orderId+" Exists"));
//		if(order.getPayment()!=null)
//			throw new PaymentAlreadyDoneException("Payment Already Done for this Order with ID "+orderId);
//		order.setPayment(payment);
//		return orderRepository.save(order);
//	}

}
