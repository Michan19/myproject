package com.ecommerce.backend.entities;

import org.springframework.validation.annotation.Validated;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Validated
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "userid")
    private Long userID;

    @NotBlank(message = "Name is mandatory")
    @Size(max = 100, message = "Name can have a maximum of 100 characters")
    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @NotBlank(message = "Email is mandatory")
    @Email(message = "Email should be valid")
    @Size(max = 100, message = "Email can have a maximum of 100 characters")
    @Column(name = "email", nullable = false, unique = true, length = 100)
    private String email;

    @NotBlank(message = "Password is mandatory")
    @Pattern(
        regexp = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=]).{8,}$",
        message = "Password must be 8 characters long and contain at least one number, one uppercase letter, and one special character"
    )
    @Column(name = "password", nullable = false)
    private String password;

    @Size(max = 255, message = "Shipping address can have a maximum of 255 characters")
    @Column(name = "shippingaddress", length = 255)
    private String shippingAddress;

    @Size(max = 255, message = "Payment details can have a maximum of 255 characters")
    @Column(name = "paymentdetails", length = 255)
    private String paymentDetails;

    @Column(name = "role")
    private String role;
}