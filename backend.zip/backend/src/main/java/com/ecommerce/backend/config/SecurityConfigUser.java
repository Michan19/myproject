package com.ecommerce.backend.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.ecommerce.backend.entities.Admin;
import com.ecommerce.backend.repositories.AdminRepository;
import com.ecommerce.backend.repositories.UserRepository;

@Service
public class SecurityConfigUser implements UserDetailsService {

    @Autowired
   AdminRepository adminRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Check if the email is in the admin table
        Admin admin = adminRepository.findByEmail(username).orElse(null);
        if (admin != null) {
            List<GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority(admin.getRole()));
            return new User(admin.getEmail(), admin.getPassword(), authorities);
        }

        // If not found in the admin table, check the user table
        com.ecommerce.backend.entities.User user = userRepository.findByEmail(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        List<GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority(user.getRole()));
        return new User(user.getEmail(), user.getPassword(), authorities);
    }
}