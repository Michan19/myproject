package com.ecommerce.backend.controllers;

import java.util.List;

import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.backend.dto.OrderConfirmationDTO;
import com.ecommerce.backend.dto.OrderDTO;
import com.ecommerce.backend.entities.Order;
import com.ecommerce.backend.exceptions.OrderNotFoundException;

import com.ecommerce.backend.services.OrderService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/order")
public class OrderController {
	@Autowired
	private OrderService orderService;

	@GetMapping("/{userId}/orders")
	public List<Order> giveAllOrders(@PathVariable Long userId) {
		return orderService.showAllOrders(userId);
	}

	@PostMapping("/addOrder")
	public ResponseEntity<OrderConfirmationDTO> placeNewOrder(@Valid @RequestBody OrderDTO orderDto)throws BadRequestException {
		return new ResponseEntity<OrderConfirmationDTO>(orderService.addNewOrder(orderDto), HttpStatus.CREATED);
	}

	@PutMapping("/{userId}/{orderId}/{address}")
	public ResponseEntity<String> changeAddress(@PathVariable Long userId, @PathVariable Long orderId,
			@PathVariable String address) throws OrderNotFoundException, RuntimeException {
		String confirmation = orderService.updateAddress(userId, orderId, address);
		return new ResponseEntity<String>(confirmation, HttpStatus.OK);
	}

	@GetMapping("/{userId}/{orderId}/status")
	public ResponseEntity<?> giveOrderStatus(@PathVariable Long userId, @PathVariable Long orderId)
			throws OrderNotFoundException, RuntimeException {
		String confirmation = orderService.getOrderStatus(userId, orderId);
		return confirmation != null ? new ResponseEntity<String>(confirmation, HttpStatus.OK)
				: new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}

	@DeleteMapping("/{userId}/{orderId}")
	public ResponseEntity<String> cancelOrder(@PathVariable Long userId, @PathVariable Long orderId)
			throws OrderNotFoundException, RuntimeException {
		String confirmation = orderService.deleteOrder(userId, orderId);
		return new ResponseEntity<String>(confirmation, HttpStatus.OK);

	}

	@GetMapping("/{userId}/{orderId}")
	public ResponseEntity<?> getOrderInfo(@PathVariable Long userId, @PathVariable Long orderId)
			throws OrderNotFoundException, RuntimeException {

		Order order = orderService.findOrderDetails(userId, orderId);
		return order != null ? new ResponseEntity<Order>(order, HttpStatus.OK)
				: new ResponseEntity<String>(HttpStatus.NOT_FOUND);

	}

	@GetMapping("/{userId}/{orderId}/paymentStatus")
	public ResponseEntity<?> findPayStatus(@PathVariable Long userId, @PathVariable Long orderId)
			throws OrderNotFoundException, RuntimeException {

		return new ResponseEntity<String>(orderService.findPaymentStatus(userId, orderId), HttpStatus.OK);

	}
}
