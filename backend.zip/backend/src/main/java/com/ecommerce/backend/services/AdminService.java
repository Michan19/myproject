package com.ecommerce.backend.services;

import com.ecommerce.backend.dto.AdminDTO;
import com.ecommerce.backend.dto.ProductDTO;
import com.ecommerce.backend.dto.UserDTO;
import com.ecommerce.backend.entities.Order;
import com.ecommerce.backend.entities.Product;

import java.util.List;
import java.util.Map;

public interface AdminService {
	AdminDTO createAdmin(AdminDTO adminDTO);

	AdminDTO getAdminById(Long adminID);

	List<AdminDTO> getAllAdmins();

	AdminDTO updateAdmin(Long adminID, AdminDTO adminDTO);

	void deleteAdmin(Long adminID);

	List<ProductDTO> listAllProducts();

	List<UserDTO> listAllUsers();

	List<Order> listAllOrders();

	List<ProductDTO> getProductsByIdOrderById(Long productID);

	ProductDTO createProduct(ProductDTO productDTO);

	ProductDTO updateProduct(Long productID, ProductDTO productDTO);

	void deleteProduct(Long productID);

	Order getOrderByOrderId(Long orderID);

	List<Order> getOrdersByUserId(Long userID);

	double calculateTotalSales();

	// List<Product> getMostOrderedProducts();
	// Map<Product, Integer> getProductOrderCounts();
	List<Object[]> getTopCustomers();

	List<Object[]> getOrderStatusDistribution();
}
