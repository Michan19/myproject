package com.ecommerce.backend.controllers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.backend.dto.ProductDTO;
import com.ecommerce.backend.exceptions.ResourceNotFoundException;
import com.ecommerce.backend.entities.Product;
import com.ecommerce.backend.services.ProductService;

@RestController
@RequestMapping("/api/products")
public class ProductController {
	@Autowired
	private ProductService productService;

	@GetMapping
	public List<ProductDTO> getAllProducts() {
		return productService.getAllProducts().stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	@GetMapping("/{id}")
	public ResponseEntity<ProductDTO> getProductById(@PathVariable Long id) {
		Product product = productService.getProductById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Product not found"));
		return ResponseEntity.ok(convertToDTO(product));
	}
	
	@GetMapping("/category/{category}")
 	public List<ProductDTO> getProductsByCategory(@PathVariable String category) {
 		return productService.getProductsByCategory(category).stream().map(this::convertToDTO)
 				.collect(Collectors.toList());
 	}

	@PostMapping("/addProduct")
	public ProductDTO createProduct(@RequestBody ProductDTO productDTO) {
		Product product = productService.createProduct(convertToEntity(productDTO));
		return convertToDTO(product);
	}

	@PutMapping("/{id}")
	public ResponseEntity<ProductDTO> updateProduct(@PathVariable Long id, @RequestBody ProductDTO productDTO) {
		Product updatedProduct = productService.updateProduct(id, convertToEntity(productDTO));
		return ResponseEntity.ok(convertToDTO(updatedProduct));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteProduct(@PathVariable Long id) {
		productService.deleteProduct(id);
		return ResponseEntity.ok("Product deleted successfully");
	}

	private ProductDTO convertToDTO(Product product) {
		return new ProductDTO(product.getProductID(), product.getName(), product.getDescription(), product.getPrice(),
				product.getCategory(), product.getImageURL());
	}

	private Product convertToEntity(ProductDTO productDTO) {
	    return new Product(
	        productDTO.getProductID(),
	        productDTO.getName(),
	        productDTO.getDescription(),
	        productDTO.getPrice(),
	        productDTO.getCategory(),
	        productDTO.getImageURL()
	    );
	}
}