package com.ecommerce.backend.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AdminDTO {
	private Long adminID;

	@NotBlank(message = "Name is mandatory")
	@Size(max = 100, message = "Name should not exceed 100 characters")
	private String name;

	@NotBlank(message = "Role is mandatory")
	@Size(max = 50, message = "Role should not exceed 50 characters")
	
	private String role;

	@NotBlank(message = "Permissions are mandatory")
	private String permissions;

	@Email(message = "Email should be valid")
	@NotBlank(message = "Email is mandatory")
	@Size(max = 100, message = "Email should not exceed 100 characters")
	private String email;

	@NotBlank(message = "Password is mandatory")
	@Size(min = 8, message = "Password should have at least 8 characters")
	@Pattern(regexp = "^(?=.*[0-9])(?=.*[a-zA-Z]).{8,}$", message = "Password must contain at least one letter and one number")
	private String password;
}