package com.ecommerce.backend.dto;

import lombok.Data;

@Data
public class CartItemDTO {
	private Long cartItemId;
	private Long productId;
	private String productName;
	private Long userId;
	private Integer quantity;
	private Double totalPrice;

	// Getters and Setters
}