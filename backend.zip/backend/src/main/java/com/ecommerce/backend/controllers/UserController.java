package com.ecommerce.backend.controllers;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.ecommerce.backend.entities.User;
import com.ecommerce.backend.services.UserService;

import jakarta.validation.Valid;


@RestController
@RequestMapping("/api/users")
public class UserController {

	@Autowired
	private UserService userService;

	@GetMapping("/{userID}")
	public ResponseEntity<User> getUserById(@PathVariable Long userID) {
		User authenticatedUser = getAuthenticatedUser();
		if (!authenticatedUser.getUserID().equals(userID)) {
			throw new RuntimeException("You are not authorized to view this user's data.");
		}
		User user = userService.getUserById(userID);
		return ResponseEntity.ok(user);
	}

	@PutMapping("/{userID}")
	public ResponseEntity<User> updateUser(@PathVariable Long userID,@Valid @RequestBody User userDetails) {
		User authenticatedUser = getAuthenticatedUser();
		if (!authenticatedUser.getUserID().equals(userID)) {
			throw new RuntimeException("You are not authorized to update this user's data.");
		}
		User updatedUser = userService.updateUser(userID, userDetails);
		return ResponseEntity.ok(updatedUser);
	}

	@DeleteMapping("/{userID}")
	public ResponseEntity<String> deleteUser(@PathVariable Long userID) {
		User authenticatedUser = getAuthenticatedUser();
		if (!authenticatedUser.getUserID().equals(userID)) {
			throw new RuntimeException("You are not authorized to delete this user's data.");
		}
		String deleteMsg = userService.deleteUser(userID);
		return ResponseEntity.ok(deleteMsg);
	}

	@PostMapping("/addUser")
	public ResponseEntity<User> createUser(@Valid @RequestBody User user) {
		User savedUser = userService.saveUser(user);
		return ResponseEntity.ok(savedUser);
	}

	private User getAuthenticatedUser() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication == null) {
			throw new RuntimeException("User is not authenticated");
		}
		String username = authentication.getName();
		return userService.findByEmail(username);
	}
}