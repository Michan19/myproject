package com.ecommerce.backend.services.impl;

import java.util.List;

import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.ecommerce.backend.dto.OrderConfirmationDTO;
import com.ecommerce.backend.dto.OrderDTO;
import com.ecommerce.backend.entities.CartItem;
import com.ecommerce.backend.entities.Order;
import com.ecommerce.backend.entities.User;
import com.ecommerce.backend.exceptions.OrderNotFoundException;
import com.ecommerce.backend.repositories.CartRepository;
import com.ecommerce.backend.repositories.OrderRepository;
import com.ecommerce.backend.repositories.UserRepository;
import com.ecommerce.backend.services.OrderService;
import com.ecommerce.backend.services.UserService;

@Service
public class OrderServiceImpl implements OrderService {
	@Autowired
	private OrderRepository orderRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private UserService userService;
	@Autowired
	private CartRepository cartRepository;

	private Order findOrderById(Long orderId) throws OrderNotFoundException {
		return orderRepository.findById(orderId).orElseThrow(() -> new OrderNotFoundException("Order Does not Exist"));
	}

	private User findUserById(Long userId) throws UsernameNotFoundException {
		return userRepository.findById(userId).orElseThrow(() -> new UsernameNotFoundException("User not found"));
	}

	private User getAuthenticatedUser() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication == null) {
			throw new RuntimeException("User is not authenticated");
		}
		String username = authentication.getName();
		return userService.findByEmail(username);
	}

	@Override
	public List<Order> showAllOrders(Long userId) {
		User authenticatedUser = getAuthenticatedUser();
		if (!authenticatedUser.getUserID().equals(userId)) {
			throw new RuntimeException("You are not authorized to view all the orders of someone else.");
		}

		return orderRepository.findByUser_UserID(userId);
	}

	@Override
	public OrderConfirmationDTO addNewOrder(OrderDTO orderDto)
			throws UsernameNotFoundException, RuntimeException, BadRequestException {
		User authenticatedUser = getAuthenticatedUser();
		if (!authenticatedUser.getUserID().equals(orderDto.getUserId())) {
			throw new RuntimeException("You are not authorized to add order for someone else.");
		}
		User user = findUserById(orderDto.getUserId());
		CartItem cartItem = cartRepository.findByCartItemIDAndUserUserID(orderDto.getCartItemId(), orderDto.getUserId())
				.orElseThrow(() -> new BadRequestException("Please add some items in the cart before you order"));
		Order order = convertToEntity(orderDto, user);
		order.setTotalPrice(cartItem.getTotalPrice() * cartItem.getQuantity());
		order.setCartItem(cartItem);
		orderRepository.save(order);
		return convertToOrderConfirmationDTO(order);
		// return "Order is Confirmed, Please do the Payment";

	}

	@Override
	public String updateAddress(Long userId, Long orderId, String address)
			throws OrderNotFoundException, RuntimeException {
		User authenticatedUser = getAuthenticatedUser();
		if (!authenticatedUser.getUserID().equals(userId)) {
			throw new RuntimeException("You are not authorized to update address for someone else.");
		}
		Order order = findOrderById(orderId);
		order.setShippingAddress(address);
		orderRepository.save(order);
		return "Shipping Address Updated";
	}

	@Override
	public String getOrderStatus(Long userId, Long orderId) throws OrderNotFoundException, RuntimeException {
		User authenticatedUser = getAuthenticatedUser();
		if (!authenticatedUser.getUserID().equals(userId)) {
			throw new RuntimeException("You are not authorized to get order status for someone else.");
		}
		Order order = findOrderById(orderId);
		return order.getOrderStatus();

	}

	@Override
	public String deleteOrder(Long userId, Long orderId) throws OrderNotFoundException, RuntimeException {
		User authenticatedUser = getAuthenticatedUser();
		if (!authenticatedUser.getUserID().equals(userId)) {
			throw new RuntimeException("You are not authorized to delete order for someone else.");
		}
		Order order = findOrderById(orderId);
		orderRepository.delete(order);
		return "Order Cancelled";
	}

	@Override
	public Order findOrderDetails(Long userId, Long orderId) throws OrderNotFoundException, RuntimeException {
		User authenticatedUser = getAuthenticatedUser();
		if (!authenticatedUser.getUserID().equals(userId)) {
			throw new RuntimeException("You are not authorized to view order details for someone else.");
		}
		Order order = findOrderById(orderId);
		return order;
	}

	@Override
	public String findPaymentStatus(Long userId, Long orderId) throws OrderNotFoundException, RuntimeException {
		User authenticatedUser = getAuthenticatedUser();
		if (!authenticatedUser.getUserID().equals(userId)) {
			throw new RuntimeException("You are not authorized to view others payment status.");
		}
		Order order = findOrderById(orderId);
		return order.getPayment() != null ? order.getPayment().getPaymentStatus() : "Payment Yet be Done";
	}

	private Order convertToEntity(OrderDTO orderDto, User user) {
		Order order = new Order();
		order.setUser(user);
		order.setOrderStatus(orderDto.getOrderStatus());
		if (orderDto.getShippingAddress() == null) {
			order.setShippingAddress(user.getShippingAddress());
		} else {
			order.setShippingAddress(orderDto.getShippingAddress());
		}
		return order;
	}

	private OrderConfirmationDTO convertToOrderConfirmationDTO(Order order) {
		OrderConfirmationDTO orderConfirmationDTO = new OrderConfirmationDTO();
		orderConfirmationDTO.setUserId(order.getUser().getUserID());
		orderConfirmationDTO.setUserName(order.getUser().getName());
		orderConfirmationDTO.setProductName(order.getCartItem().getProduct().getName());
		
		orderConfirmationDTO.setTotalPrice(formatTotalPrice(order.getCartItem().getTotalPrice(),order.getCartItem().getQuantity()));
		orderConfirmationDTO.setQuantity(order.getCartItem().getQuantity());
		orderConfirmationDTO.setShippingAddress(order.getShippingAddress());
		return orderConfirmationDTO;
	}
	
	private Double formatTotalPrice(double totalPrice,Integer quantity) {
		double res=totalPrice*quantity;
		String strRes=String.format("%.2f", res);
		return Double.parseDouble(strRes);
	}
}
