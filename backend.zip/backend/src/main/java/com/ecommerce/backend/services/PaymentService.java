package com.ecommerce.backend.services;

import org.springframework.stereotype.Service;

import com.ecommerce.backend.dto.PaymentDTO;
import com.ecommerce.backend.exceptions.OrderNotFoundException;
import com.ecommerce.backend.exceptions.PaymentAlreadyDoneException;

@Service
public interface PaymentService {
    String doPayment(Long userId,PaymentDTO paymentDto)throws PaymentAlreadyDoneException,OrderNotFoundException;
    
	//Order paymentForOrder(Long orderId, Payment payment) throws OrderNotFoundException, PaymentAlreadyDoneException;
}
