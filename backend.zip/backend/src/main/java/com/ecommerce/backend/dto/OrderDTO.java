package com.ecommerce.backend.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Data
public class OrderDTO {
   @NotNull(message="user id cannot be empty")
   private Long userId;
   private String shippingAddress;
   @NotNull(message="cart item id cannot be null")
   
   private Long cartItemId;
   @NotNull(message="order status id cannot be null")
   @NotBlank(message="order status id cannot be blank")
   private String orderStatus;
}
