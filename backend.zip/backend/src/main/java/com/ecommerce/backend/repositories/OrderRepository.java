package com.ecommerce.backend.repositories;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ecommerce.backend.entities.Order;



@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    @Query("DELETE FROM Order o WHERE o.user.userID = :userID")
    void deleteByUserUserId(@Param("userID") Long userID);

   /* @Query("SELECT p FROM Order o JOIN o.products p GROUP BY p ORDER BY COUNT(p) DESC")
    List<Product> findMostOrderedProducts();

    @Query("SELECT p, COUNT(p) FROM Order o JOIN o.products p GROUP BY p ORDER BY COUNT(p) DESC")
    List<Object[]> findProductOrderCounts();*/
    @Query("SELECT o.user.userID, o.user.name, SUM(o.totalPrice) FROM Order o GROUP BY o.user ORDER BY SUM(o.totalPrice) DESC")
    List<Object[]> findTopCustomers();
    @Query("SELECT o.orderStatus, COUNT(o) FROM Order o GROUP BY o.orderStatus")
    List<Object[]> findOrderStatusDistribution();
    
    List<Order> findByUser_UserID(Long userId);

}