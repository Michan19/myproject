package com.ecommerce.backend.services.impl;

import java.text.DecimalFormat;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ecommerce.backend.dto.CartItemDTO;
import com.ecommerce.backend.entities.CartItem;
import com.ecommerce.backend.entities.Product;
import com.ecommerce.backend.entities.User;
import com.ecommerce.backend.exceptions.ResourceNotFoundException;
import com.ecommerce.backend.repositories.CartRepository;
import com.ecommerce.backend.repositories.ProductRepository;
import com.ecommerce.backend.repositories.UserRepository;
import com.ecommerce.backend.services.CartService;

@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    private static final DecimalFormat decimalFormat = new DecimalFormat("#.00");

    @Override
    public List<CartItemDTO> getAllCartItemsByUserId(Long userId) {
        return cartRepository.findByUserUserID(userId).stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public CartItemDTO getCartItemByIdAndUserId(Long cartItemID, Long userId) {
        CartItem cartItem = cartRepository.findByCartItemIDAndUserUserID(cartItemID, userId)
                .orElseThrow(() -> new ResourceNotFoundException("CartItem not found"));
        return convertToDTO(cartItem);
    }

    @Override
    public String deleteCartItemByIdAndUserId(Long cartItemID, Long userId) {
        CartItem cartItem = cartRepository.findByCartItemIDAndUserUserID(cartItemID, userId)
                .orElseThrow(() -> new ResourceNotFoundException("CartItem not found"));
        cartRepository.delete(cartItem);
        return "Cart Item Deleted Successfully.";
    }

    @Override
    public CartItemDTO addCartItem(CartItemDTO cartItemDTO) {
        Product product = productRepository.findById(cartItemDTO.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found"));
        User user = userRepository.findById(cartItemDTO.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        CartItem cartItem = convertToEntity(cartItemDTO);
        cartItem.setProduct(product);
        cartItem.setUser(user);
        cartItem.setTotalPrice(
                Double.parseDouble(decimalFormat.format(product.getPrice().doubleValue() * cartItem.getQuantity())));
        cartItem = cartRepository.save(cartItem);
        return convertToDTO(cartItem);
    }
    @Override
    public CartItemDTO updateCartItem(Long cartItemID, CartItemDTO cartItemDTO) {
        CartItem cartItem = cartRepository.findByCartItemIDAndUserUserID(cartItemID, cartItemDTO.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("CartItem not found"));
        Product product = productRepository.findById(cartItemDTO.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found"));
        User user = userRepository.findById(cartItemDTO.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        cartItem.setProduct(product);
        cartItem.setUser(user);
        cartItem.setQuantity(cartItemDTO.getQuantity());
        cartItem.setTotalPrice(
                Double.parseDouble(decimalFormat.format(product.getPrice().doubleValue() * cartItem.getQuantity())));
        cartItem = cartRepository.save(cartItem);
        return convertToDTO(cartItem);
    }

    @Override
    public Double calculateTotalPriceForUser(Long userId) {
        List<CartItem> cartItems = cartRepository.findByUserUserID(userId);
        return cartItems.stream().mapToDouble(CartItem::getTotalPrice).sum();
    }

    private CartItemDTO convertToDTO(CartItem cartItem) {
        CartItemDTO cartItemDTO = new CartItemDTO();
        cartItemDTO.setCartItemId(cartItem.getCartItemID());
        cartItemDTO.setProductId(cartItem.getProduct().getProductID());
        cartItemDTO.setProductName(cartItem.getProduct().getName());
        cartItemDTO.setUserId(cartItem.getUser().getUserID());
        cartItemDTO.setQuantity(cartItem.getQuantity());
        cartItemDTO.setTotalPrice(cartItem.getTotalPrice());
        return cartItemDTO;
    }

    private CartItem convertToEntity(CartItemDTO cartItemDTO) {
        CartItem cartItem = new CartItem();
        cartItem.setQuantity(cartItemDTO.getQuantity());
        cartItem.setTotalPrice(cartItemDTO.getTotalPrice());
        return cartItem;
    }
}