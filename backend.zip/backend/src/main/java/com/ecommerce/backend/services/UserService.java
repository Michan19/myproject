package com.ecommerce.backend.services;

import com.ecommerce.backend.entities.User;

import java.util.List;

import org.springframework.stereotype.Service;
@Service
public interface UserService {
    User saveUser(User user);

    User getUserById(Long userID);

    User updateUser(Long userID, User userDetails);

    String deleteUser(Long userID);

    List<User> listAllUsers();

    User findByEmail(String email);
}