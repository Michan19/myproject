
package com.ecommerce.backend.services.impl;

import com.ecommerce.backend.dto.AdminDTO;
import com.ecommerce.backend.dto.ProductDTO;
import com.ecommerce.backend.dto.UserDTO;
import com.ecommerce.backend.entities.Admin;
import com.ecommerce.backend.entities.Order;
import com.ecommerce.backend.entities.Product;
import com.ecommerce.backend.entities.User;
import com.ecommerce.backend.exceptions.ResourceNotFoundException;
import com.ecommerce.backend.repositories.AdminRepository;
import com.ecommerce.backend.repositories.ProductRepository;
import com.ecommerce.backend.repositories.UserRepository;
import com.ecommerce.backend.repositories.OrderRepository;
import com.ecommerce.backend.services.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;


import java.util.stream.Collectors;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public List<ProductDTO> listAllProducts() {
        return productRepository.findAll().stream()
                .map(this::mapToProductDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<UserDTO> listAllUsers() {
        return userRepository.findAll().stream()
                .map(this::mapToUserDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<Order> listAllOrders() {
        return orderRepository.findAll();
    }

    private ProductDTO mapToProductDTO(Product product) {
        ProductDTO dto = new ProductDTO();
        dto.setProductID(product.getProductID());
        dto.setName(product.getName());
        dto.setDescription(product.getDescription());
        dto.setPrice(product.getPrice());
        dto.setCategory(product.getCategory());
        dto.setImageURL(product.getImageURL());
        return dto;
    }

    private UserDTO mapToUserDTO(User user) {
        UserDTO dto = new UserDTO();
        dto.setUserID(user.getUserID());
        dto.setName(user.getName());
        dto.setEmail(user.getEmail());
        dto.setShippingAddress(user.getShippingAddress());
        dto.setPaymentDetails(user.getPaymentDetails());
        return dto;
    }

    @Override
    public AdminDTO createAdmin(AdminDTO adminDTO) {
        Admin admin = new Admin();
        admin.setName(adminDTO.getName());
        admin.setRole(adminDTO.getRole());
        admin.setPermissions(adminDTO.getPermissions());
        admin.setEmail(adminDTO.getEmail());
        admin.setPassword(passwordEncoder.encode(adminDTO.getPassword())); // Encode password here
        Admin savedAdmin = adminRepository.save(admin);
        adminDTO.setAdminID(savedAdmin.getAdminID());
        return adminDTO;
    }

    @Override
    public AdminDTO getAdminById(Long adminID) {
        Admin admin = adminRepository.findById(adminID)
                .orElseThrow(() -> new RuntimeException("Admin not found"));
        return mapToDTO(admin);
    }

    @Override
    public List<AdminDTO> getAllAdmins() {
        List<Admin> admins = adminRepository.findAll();
        return admins.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public AdminDTO updateAdmin(Long adminID, AdminDTO adminDTO) {
        Admin admin = adminRepository.findById(adminID)
                .orElseThrow(() -> new RuntimeException("Admin not found"));
        admin.setName(adminDTO.getName());
        admin.setRole(adminDTO.getRole());
        admin.setPermissions(adminDTO.getPermissions());
        admin.setEmail(adminDTO.getEmail());
        admin.setPassword(passwordEncoder.encode(adminDTO.getPassword()));
        adminRepository.save(admin);
        return mapToDTO(admin);
    }

    @Override
    public void deleteAdmin(Long adminID) {
        Admin admin = adminRepository.findById(adminID)
                .orElseThrow(() -> new RuntimeException("Admin not found"));
        adminRepository.delete(admin);
    }

    private AdminDTO mapToDTO(Admin admin) {
        AdminDTO adminDTO = new AdminDTO();
        adminDTO.setAdminID(admin.getAdminID());
        adminDTO.setName(admin.getName());
        adminDTO.setRole(admin.getRole());
        adminDTO.setPermissions(admin.getPermissions());
        adminDTO.setEmail(admin.getEmail());
        adminDTO.setPassword(admin.getPassword());
        return adminDTO;
    }

    @Override
    public List<ProductDTO> getProductsByIdOrderById(Long productID) {
        return productRepository.findById(productID)
                .stream()
                .map(this::mapToProductDTO)
                .sorted((p1, p2) -> p1.getProductID().compareTo(p2.getProductID())) 
                .collect(Collectors.toList());
    }

    @Override
    public ProductDTO createProduct(ProductDTO productDTO) {
        Product product = new Product();
        product.setName(productDTO.getName());
        product.setDescription(productDTO.getDescription());
        product.setPrice(productDTO.getPrice());
        product.setCategory(productDTO.getCategory());
        product.setImageURL(productDTO.getImageURL());
        productRepository.save(product);
        return mapToProductDTO(product);
    }

    @Override
    public ProductDTO updateProduct(Long productID, ProductDTO productDTO) {
        Product product = productRepository.findById(productID)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with ID: " + productID));
        product.setName(productDTO.getName());
        product.setDescription(productDTO.getDescription());
        product.setPrice(productDTO.getPrice());
        product.setCategory(productDTO.getCategory());
        product.setImageURL(productDTO.getImageURL());
        productRepository.save(product);
        return mapToProductDTO(product);
    }

    @Override
    public void deleteProduct(Long productID) {
        Product product = productRepository.findById(productID)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with ID: " + productID));
        productRepository.delete(product);
    }

    @Override
    public Order getOrderByOrderId(Long orderID) {
        return orderRepository.findById(orderID)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with ID: " + orderID));
    }

    @Override
    public List<Order> getOrdersByUserId(Long userID) {
        return orderRepository.findAll().stream()
                .filter(order -> order.getUser().getUserID().equals(userID))
                .collect(Collectors.toList());
    }

    @Override
    public double calculateTotalSales() {
        return orderRepository.findAll().stream()
                .mapToDouble(Order::getTotalPrice).sum();
    }
    @Override
    public List<Object[]> getTopCustomers() {
        return orderRepository.findTopCustomers();
    }
    @Override
    public List<Object[]> getOrderStatusDistribution() {
        return orderRepository.findOrderStatusDistribution();
    }

   /* @Override
    public List<Product> getMostOrderedProducts() {
        return orderRepository.findMostOrderedProducts();
    }

    @Override
    public Map<Product, Integer> getProductOrderCounts() {
        return orderRepository.findProductOrderCounts().stream()
                .collect(Collectors.toMap(
                        result -> (Product) result[0],
                        result -> ((Long) result[1]).intValue()
                ));
    }*/

}