package com.ecommerce.backend.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.core.GrantedAuthorityDefaults;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http.csrf().disable().authorizeHttpRequests((requests) -> requests
				.requestMatchers("/api/products", "/api/admins/addAdmin", "api/users/addUser", "api/products/{id}",
						"/api/products/category/{category}")
				.permitAll().requestMatchers("/api/admins/**").hasRole("ADMIN")
				.requestMatchers("/order/orders", "/order/neworder", "/order/{id}/{address}", "/order/{id}/status",
						"/order/{id}", "/order/{id}/paymentstatus", "payment", "updatepayment/{id}")
				.hasRole("USER").requestMatchers("/api/admins/orderList").hasRole("ADMIN")
				.requestMatchers("/api/admins/userList").hasRole("ADMIN").requestMatchers("/api/admins/products/**")
				.hasRole("ADMIN").requestMatchers("/api/admins/orders/users/{userId}").hasRole("ADMIN")
				.requestMatchers("/api/admins/orders/{orderId}").hasRole("ADMIN")
				.requestMatchers("/api/admins/reports/sales").hasRole("ADMIN").requestMatchers("/api/users/{id}")
				.hasRole("USER").requestMatchers("/api/cart/**").hasRole("USER")
				// .requestMatchers("/api/users/**").hasRole("ADMIN")
				.anyRequest().authenticated())
				//.formLogin(form -> form.loginPage("/login").defaultSuccessUrl("/admin/home", true).permitAll())
				.httpBasic();
		return http.build();
	}

	@Bean
	public GrantedAuthorityDefaults grantedAuthorityDefaults() {
		return new GrantedAuthorityDefaults(""); // Remove the "ROLE_" prefix
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
}