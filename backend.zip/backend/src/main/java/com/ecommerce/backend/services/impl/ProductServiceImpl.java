package com.ecommerce.backend.services.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.backend.exceptions.ResourceNotFoundException;
import com.ecommerce.backend.entities.Product;
import com.ecommerce.backend.repositories.ProductRepository;
import com.ecommerce.backend.services.ProductService;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductRepository productRepository;

	@Override
	public List<Product> getAllProducts() {
		return productRepository.findAll();
	}

	@Override
	public Optional<Product> getProductById(Long id) {
		return productRepository.findById(id);
	}
	
	@Override
 	public List<Product> getProductsByCategory(String category) {
 		return productRepository.findByCategory(category);
 	}

	@Override
	public Product createProduct(Product product) {
		return productRepository.save(product);
	}

	@Override
	public Product updateProduct(Long id, Product productDetails) {
		Product product = productRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Product not found"));
		product.setName(productDetails.getName());
		product.setDescription(productDetails.getDescription());
		product.setPrice(productDetails.getPrice());
		product.setCategory(productDetails.getCategory());
		product.setImageURL(productDetails.getImageURL());
		return productRepository.save(product);
	}

	@Override
	public String deleteProduct(Long id) {
		Product product = productRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Product not found"));
		productRepository.delete(product);
		return "Product deleted successfully";
	}
}