package com.ecommerce.backend.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.ecommerce.backend.entities.Product;
@Service
public interface ProductService {
	List<Product> getAllProducts();

	Optional<Product> getProductById(Long id);

	Product createProduct(Product product);

	Product updateProduct(Long id, Product productDetails);

	String deleteProduct(Long id);

	List<Product> getProductsByCategory(String category);
}