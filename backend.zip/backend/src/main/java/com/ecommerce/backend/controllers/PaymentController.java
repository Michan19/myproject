package com.ecommerce.backend.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.backend.dto.PaymentDTO;
import com.ecommerce.backend.entities.Order;
import com.ecommerce.backend.entities.Payment;
import com.ecommerce.backend.exceptions.OrderNotFoundException;
import com.ecommerce.backend.exceptions.PaymentAlreadyDoneException;
import com.ecommerce.backend.services.impl.PaymentServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {
   @Autowired
   private PaymentServiceImpl paymentServiceImpl;
   @PostMapping("/{userId}/pay")
   public String doPay(@PathVariable Long userId,@Valid @RequestBody PaymentDTO pay) throws OrderNotFoundException {
	   return paymentServiceImpl.doPayment(userId,pay);
   }
//   @PutMapping("/updatepayment/{id}")
//   public ResponseEntity<?> updatePay(@PathVariable Long id,@RequestBody Payment pay) {
//	   try {
//		  return new ResponseEntity<Order>(paymentServiceImpl.paymentForOrder(id,pay),HttpStatus.ACCEPTED);		   
//	   }
//	   catch(OrderNotFoundException e) {
//		 return new ResponseEntity<String>(e.getMessage(),HttpStatus.NOT_FOUND);
//	   }
//	   catch(PaymentAlreadyDoneException e) {
//			 return new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST);
//		   } 
//	   
//   }
}
