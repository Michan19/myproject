package com.ecommerce.backend.controllers;

import com.ecommerce.backend.dto.AdminDTO;
import com.ecommerce.backend.dto.ProductDTO;
import com.ecommerce.backend.dto.UserDTO;
import com.ecommerce.backend.entities.Order;
import com.ecommerce.backend.entities.Product;
import com.ecommerce.backend.services.AdminService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class AdminController {
    @Autowired
    private AdminService adminService;

    @PostMapping("/admins/addAdmin")
    public AdminDTO createAdmin(@Valid @RequestBody AdminDTO adminDTO) {
        return adminService.createAdmin(adminDTO);
    }

    @GetMapping("/admins/{adminID}")
    public AdminDTO getAdminById(@PathVariable Long adminID) {
        return adminService.getAdminById(adminID);
    }

    @GetMapping("/admins/list")
    public List<AdminDTO> getAllAdmins() {
        return adminService.getAllAdmins();
    }

    @PutMapping("/admins/{adminID}")
    public AdminDTO updateAdmin(@PathVariable Long adminID, @Valid @RequestBody AdminDTO adminDTO) {
        return adminService.updateAdmin(adminID, adminDTO);
    }

    @DeleteMapping("/admins/{adminID}")
    public void deleteAdmin(@PathVariable Long adminID) {
        adminService.deleteAdmin(adminID);
    }

    @GetMapping("/admins/userList")
    public List<UserDTO> listAllUsers() {
        return adminService.listAllUsers();
    }

    @GetMapping("/admins/orderList")
    public List<Order> listAllOrders() {
        return adminService.listAllOrders();
    }

    @PostMapping("/admins/products")
    public ProductDTO createProduct(@Valid @RequestBody ProductDTO productDTO) {
        return adminService.createProduct(productDTO);
    }

    @PutMapping("/admins/products/{id}")
    public ProductDTO updateProduct(@PathVariable Long id, @Valid @RequestBody ProductDTO productDTO) {
        return adminService.updateProduct(id, productDTO);
    }

    @DeleteMapping("/admins/products/{id}")
    public void deleteProduct(@PathVariable Long id) {
        adminService.deleteProduct(id);
    }

    @GetMapping("/admins/orders/{orderID}")
    public Order getOrderByOrderId(@PathVariable Long orderID) {
        return adminService.getOrderByOrderId(orderID);
    }

    @GetMapping("/admins/orders/users/{userId}")
    public List<Order> getOrdersByUserId(@PathVariable Long userId) {
        return adminService.getOrdersByUserId(userId);
    }

    @GetMapping("/admins/reports/sales")
    public double calculateTotalSales() {
        return adminService.calculateTotalSales();
    }

    @GetMapping("/admins/reports/topCustomers")
    public List<Object[]> getTopCustomers() {
        return adminService.getTopCustomers();
    }

    @GetMapping("/admins/reports/orderStatusDistribution")
    public List<Object[]> getOrderStatusDistribution() {
        return adminService.getOrderStatusDistribution();
    }
}