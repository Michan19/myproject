package com.ecommerce.backend.repositories;

import com.ecommerce.backend.entities.Product;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
	List<Product> findByCategory(String category);
}
