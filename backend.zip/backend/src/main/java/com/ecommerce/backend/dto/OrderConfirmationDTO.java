package com.ecommerce.backend.dto;

import lombok.Data;

@Data
public class OrderConfirmationDTO {
    private Long userId;
    private String userName;
    private String productName;
    private Double totalPrice;
    private Integer quantity;
    private String shippingAddress;
}
