
package com.ecommerce.backend.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ecommerce.backend.dto.CartItemDTO;
@Service
public interface CartService {
    List<CartItemDTO> getAllCartItemsByUserId(Long userId);
    CartItemDTO getCartItemByIdAndUserId(Long cartItemID, Long userId);
    CartItemDTO addCartItem(CartItemDTO cartItemDTO);
    CartItemDTO updateCartItem(Long cartItemID, CartItemDTO cartItemDTO);
    String deleteCartItemByIdAndUserId(Long cartItemID, Long userId);
    Double calculateTotalPriceForUser(Long userId);
}