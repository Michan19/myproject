package com.ecommerce.backend.exceptions;

public class PaymentAlreadyDoneException extends Exception {
    public PaymentAlreadyDoneException(String msg) {
		super(msg);
	}
}
